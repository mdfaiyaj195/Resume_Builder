from django.db import models

class Resume(models.Model):
    image = models.ImageField(upload_to='images/', blank=True, null=True)
    name = models.CharField(max_length=100)
    fathers_name = models.CharField(max_length=100)
    mothers_name = models.CharField(max_length=100)
    college_name = models.CharField(max_length=200)
    mobile_no = models.CharField(max_length=15)
    email_id = models.EmailField()
    dob = models.DateField()
    language = models.CharField(max_length=100)
    nationalty = models.CharField(max_length=100)
    gender = models.CharField(max_length=10)
    martial_status = models.CharField(max_length=20)
    category = models.CharField(max_length=50)

    achievement = models.TextField(blank=True, null=True)
    certification = models.TextField(blank=True, null=True)
    hobies = models.TextField(blank=True, null=True)
    interest = models.TextField(blank=True, null=True)
    internship = models.TextField(blank=True, null=True)
    declaration = models.TextField(blank=True, null=True)
    address = models.TextField(blank=True, null=True)

    degree1 = models.CharField(max_length=100, blank=True, null=True)
    university1 = models.CharField(max_length=200, blank=True, null=True)
    percentage1 = models.IntegerField(blank=True, null=True)
    year1 = models.IntegerField(blank=True, null=True)

    degree2 = models.CharField(max_length=100, blank=True, null=True)
    university2 = models.CharField(max_length=200, blank=True, null=True)
    percentage2 = models.IntegerField(blank=True, null=True)
    year2 = models.IntegerField(blank=True, null=True)
    
    degree3 = models.CharField(max_length=100, blank=True, null=True)
    university3 = models.CharField(max_length=200, blank=True, null=True)
    percentage3 = models.IntegerField(blank=True, null=True)
    year3 = models.IntegerField(blank=True, null=True)

    project_name = models.CharField(max_length=200, blank=True, null=True)
    duration = models.CharField(max_length=50, blank=True, null=True)
    team_size = models.PositiveIntegerField(blank=True, null=True)
    project2 = models.CharField(max_length=500, blank=True, null=True)

    skill1 = models.CharField(max_length=100, blank=True, null=True)
    skill2 = models.CharField(max_length=100, blank=True, null=True)
    skill3 = models.CharField(max_length=100, blank=True, null=True)
    skill4 = models.CharField(max_length=100, blank=True, null=True)
    skill5 = models.CharField(max_length=100, blank=True, null=True)
    skill6 = models.CharField(max_length=100, blank=True, null=True)
    skill7 = models.CharField(max_length=100, blank=True, null=True)

    # Objective
    objective = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.name
