from django.shortcuts import render, redirect
from .models import Resume

def index(request):
    if request.method == "POST":
        IMAGE=request.POST["image"]
        NAME = request.POST["name"]
        FATHERS_NAME = request.POST["fathers_name"]
        MOTHERS_NAME = request.POST["mothers_name"]
        COLLEGE_NAME = request.POST["college_name"]
        MOBILE_NO = request.POST["mobile_no"]
        EMAIL_ID = request.POST["email_id"]
        DOB = request.POST["dob"]
        LANGUAGE = request.POST["language"]
        NATIONALTY = request.POST["nationalty"]
        GENDER = request.POST["gender"]
        MARTIAL_STATUS = request.POST["martial_status"]
        CATEGORY = request.POST["category"]
        ACHIEVEMENT = request.POST["achievement"]
        CERTIFICATION = request.POST["certification"]
        HOBIES = request.POST["hobies"]
        INTEREST = request.POST["interest"]
        INTERNSHIP = request.POST["internship"]
        DECLARATION = request.POST["declaration"]
        ADDRESS = request.POST["address"]

        DEGREE1 = request.POST["degree1"]
        UNIVERSITY1 = request.POST["university1"]
        PERCENTAGE1 = request.POST["percentage1"]
        YEAR1 = request.POST["year1"]

        DEGREE2 = request.POST["degree2"]
        UNIVERSITY2 = request.POST["university2"]
        PERCENTAGE2 = request.POST["percentage3"]
        YEAR2 = request.POST["year1"]

        DEGREE3 = request.POST["degree3"]
        UNIVERSITY3 = request.POST["university3"]
        PERCENTAGE3 = request.POST["percentage3"]
        YEAR3 = request.POST["year3"]

        PROJECT_NAME= request.POST["project_name"]
        DURATION= request.POST["duration"]
        TEAM_SIZE= request.POST["team_size"]
        PROJECT2= request.POST["project2"]

        SKILL1 = request.POST["skill1"]
        SKILL2 = request.POST["skill2"]
        SKILL3 = request.POST["skill3"]
        SKILL4 = request.POST["skill4"]
        SKILL5 = request.POST["skill5"]
        SKILL6 = request.POST["skill6"]
        SKILL7 = request.POST["skill7"]

        OBJECTIVE = request.POST["objective"]

        # Save to the database
        infoo = Resume ( image=IMAGE, name=NAME,fathers_name =FATHERS_NAME, mothers_name = MOTHERS_NAME,college_name = COLLEGE_NAME,mobile_no =MOBILE_NO,email_id = EMAIL_ID,
            dob = DOB,language = LANGUAGE, nationalty = NATIONALTY,gender = GENDER,martial_status =MARTIAL_STATUS, category = CATEGORY,achievement = ACHIEVEMENT,certification = CERTIFICATION,hobies = HOBIES,
            interest = INTEREST,internship = INTERNSHIP,declaration = DECLARATION,address = ADDRESS,degree1 = DEGREE1,university1 = UNIVERSITY1, percentage1 = PERCENTAGE1,year1 = YEAR1,degree2 = DEGREE2,university2 = UNIVERSITY2,percentage2 = PERCENTAGE2,year2 = YEAR2,
            degree3 = DEGREE3,university3 = UNIVERSITY3,percentage3 = PERCENTAGE3,year3 = YEAR3,project_name= PROJECT_NAME,duration= DURATION,team_size= TEAM_SIZE,project2= PROJECT2,skill1= SKILL1,skill2= SKILL2,skill3=SKILL3,skill4= SKILL4,skill5= SKILL5,skill6= SKILL6,skill7= SKILL7,objective=  OBJECTIVE,
        )
        infoo.save()
        return redirect('result')
    return render(request, 'resume.html')
    
def result(request):
    all_info = Resume.objects.all()
    return render(request, 'print.html', {'all_info': all_info})

def res(request):
    return render(request, 'print.html')